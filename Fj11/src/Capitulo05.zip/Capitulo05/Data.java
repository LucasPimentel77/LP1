package Capitulo05;

public class Data {

}
